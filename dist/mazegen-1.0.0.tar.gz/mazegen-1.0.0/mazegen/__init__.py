"""Maze generator package."""
